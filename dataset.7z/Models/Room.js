const mongoose = require("mongoose");

const RoomSchema = new mongoose.Schema({
  sede: {
    type: String,
    required: true,
  },
  edificioId: {
    type: Number,
  },
  aulaId: {
    type: Number,
  },
  aulaCod: {
    type: String,
  },
  aulaDes: {
    type: String,
    required: true,
  },
  capienza: {
    type: Number,
    required: true,
  },
  abilFlg: {
    type: Number,
  },
  poloDes: {
    type: String,
    required: true,
  },
  poloCod: {
    type: String,
  },
  comuneId: {
    type: Number,
  },
  indirizzo: {
    type: String,
  },
  email: {
    type: String,
  },
  telefono: {
    type: String,
  },
  numeroPersone: {
    type: Number,
    default: 0,
  },
  bookable: {
    type: Boolean,
  },
  scheduleType: [],
  postiAssegnati: [],
  schedules: [
    {
      day: {
        type: String,
      },
      month: {
        type: String,
      },
      year: {
        type: String,
      },
      roomSchedule: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "roomSchedule",
      },
    },
  ],
  date: {
    type: Date,
    default: Date.now,
  },
});

module.exports = Room = mongoose.model("room", RoomSchema);
