const mongoose = require("mongoose");

const RoomScheduleSchema = new mongoose.Schema({
  bookings: [
    {
      start: {
        type: String,
      },
      end: {
        type: String,
      },
      persons: [
        {
          username: {
            type: String,
          },
          id: {
            type: String,
          },
        },
      ],
      availability: [],
    },
  ],
  room: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "room",
  },
  date: {
    type: Date,
    default: Date.now,
    // expires: 1814400, //3 week
  },
});

module.exports = RoomSchedule = mongoose.model(
  "roomSchedule",
  RoomScheduleSchema
);
