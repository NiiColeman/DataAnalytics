const mongoose = require("mongoose");

const RoomBookingSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
  },
  username: {
    type: String,
    required: true,
  },
  aula: {
    type: String,
    required: true,
  },
  polo: {
    type: String,
    required: true,
  },
  sede: {
    type: String,
    required: true,
  },
  day: {
    type: Number,
    required: true,
    min: 1,
    max: 31,
  },
  month: {
    type: Number,
    required: true,
    min: 1,
    max: 12,
  },
  year: {
    type: Number,
    required: true,
  },
  time: {
    start: {
      type: String,
      required: true,
    },
    end: {
      type: String,
      required: true,
    },
  },
  googleCalendarId: {
    type: String,
    required: true,
  },
  bookingDate: {
    type: Date,
    default: Date.now,
    // expires: 1814400, //3 week
  },
});

module.exports = RoomBooking = mongoose.model("roomBooking", RoomBookingSchema);
