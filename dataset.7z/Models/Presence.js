const mongoose = require("mongoose");

const PresenceSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
  },
  username: {
    type: String,
    required: true,
  },
  aula: {
    type: String,
    required: true,
  },
  sede: {
    type: String,
    required: true,
  },
  polo: {
    type: String,
    required: true,
  },
  posto: {
    type: Number,
  },
  inDate: {
    type: Date,
  },
  outDate: {
    type: Date,
  },
  date: {
    type: Date,
    default: Date.now,
    // expires: 1814400, //3 week
  },
});

module.exports = Presence = mongoose.model("presence", PresenceSchema);
